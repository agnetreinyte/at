var canvas=document.getElementById('canvas');
var context=canvas.getContext('2d');

var radius=5;
var dragging=false;

canvas.width=window.innerWidth;
canvas.height=window.innerHeight;
context.lineWidth=radius*2;

var draw=function(e){
   if(dragging){
   context.lineTo(e.clientX, e.clientY);
   context.stroke();
   context.beginPath();
   context.arc(e.clientX, e.clientY, radius, 0, Math.PI*2);
   context.fill();
   context.beginPath();
   context.moveTo(e.clientX, e.clientY);
   }
}

var start_draw=function(e) {
	dragging=true;
	draw(e);

}
var stop_draw=function(){
	dragging=false;
	context.beginPath();
}
canvas.addEventListener('mousedown', start_draw);
canvas.addEventListener('mousemove', draw);
canvas.addEventListener('mouseup', stop_draw)